package com.example.workprofiledpc

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.UserManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var devicePolicyManager: DevicePolicyManager
    private lateinit var adminComponent: ComponentName
    private lateinit var recyclerView: RecyclerView
    private lateinit var btnCreateWorkProfile: Button
    private lateinit var btnDeleteWorkProfile: Button
    private lateinit var tvStatus: TextView

    private val provisioningLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        when (result.resultCode) {
            Activity.RESULT_OK -> {
                Toast.makeText(this, "Work Profile created successfully!", Toast.LENGTH_LONG).show()
                updateUI()
            }
            Activity.RESULT_CANCELED -> {
                Toast.makeText(this, "Work Profile creation was cancelled.", Toast.LENGTH_SHORT).show()
            }
            else -> {
                Toast.makeText(this, "Work Profile creation failed (code: ${result.resultCode}).", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        adminComponent = ComponentName(this, MyDeviceAdminReceiver::class.java)

        btnCreateWorkProfile = findViewById(R.id.btnCreateWorkProfile)
        btnDeleteWorkProfile = findViewById(R.id.btnDeleteWorkProfile)
        tvStatus = findViewById(R.id.tvStatus)
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        btnCreateWorkProfile.setOnClickListener { createWorkProfile() }
        btnDeleteWorkProfile.setOnClickListener { deleteWorkProfile() }

        updateUI()
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    private fun updateUI() {
        val isProfileOwner = devicePolicyManager.isProfileOwnerApp(packageName)
        val hasWorkProfile = isWorkProfilePresent()

        when {
            isProfileOwner -> {
                tvStatus.text = "Status: Work Profile ACTIVE (This app is Profile Owner)"
                btnCreateWorkProfile.isEnabled = false
                btnDeleteWorkProfile.isEnabled = true
                loadPersonalApps()
            }
            hasWorkProfile -> {
                tvStatus.text = "Status: Work Profile exists (managed by another DPC)"
                btnCreateWorkProfile.isEnabled = false
                btnDeleteWorkProfile.isEnabled = false
                recyclerView.adapter = null
            }
            else -> {
                tvStatus.text = "Status: No Work Profile"
                btnCreateWorkProfile.isEnabled = true
                btnDeleteWorkProfile.isEnabled = false
                recyclerView.adapter = null
            }
        }
    }

    private fun isWorkProfilePresent(): Boolean {
        val userManager = getSystemService(Context.USER_SERVICE) as UserManager
        return userManager.userProfiles.size > 1
    }

    private fun createWorkProfile() {
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_MANAGED_USERS)) {
            Toast.makeText(
                this,
                "This device does not support managed profiles.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val intent = Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE).apply {
            putExtra(
                DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME,
                adminComponent
            )
            putExtra(
                DevicePolicyManager.EXTRA_PROVISIONING_SKIP_ENCRYPTION,
                true
            )
        }

        if (intent.resolveActivity(packageManager) != null) {
            provisioningLauncher.launch(intent)
        } else {
            Toast.makeText(
                this,
                "Your device or Android version does not support Work Profile provisioning.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun deleteWorkProfile() {
        AlertDialog.Builder(this)
            .setTitle("Delete Work Profile")
            .setMessage(
                "This will permanently wipe the Work Profile and all its data. " +
                "This action cannot be undone. Are you sure?"
            )
            .setPositiveButton("Delete") { _, _ ->
                try {
                    devicePolicyManager.wipeData(DevicePolicyManager.WIPE_RESET_PROTECTION_DATA)
                    Toast.makeText(this, "Work Profile deletion initiated.", Toast.LENGTH_SHORT).show()
                } catch (e: SecurityException) {
                    Toast.makeText(
                        this,
                        "Cannot delete: This app is not the Profile Owner. Error: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun loadPersonalApps() {
        val pm = packageManager
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { appInfo ->
                (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                pm.getLaunchIntentForPackage(appInfo.packageName) != null
            }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        recyclerView.adapter = AppListAdapter(
            apps = installedApps,
            packageManager = pm,
            onCloneClick = { appInfo -> cloneToWorkProfile(appInfo.packageName) }
        )
    }

    private fun cloneToWorkProfile(packageName: String) {
        val isProfileOwner = devicePolicyManager.isProfileOwnerApp(this.packageName)
        if (!isProfileOwner) {
            Toast.makeText(
                this,
                "This app is not the Profile Owner. Cannot manage Work Profile apps.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        try {
            val hidden = devicePolicyManager.isApplicationHidden(adminComponent, packageName)
            devicePolicyManager.setApplicationHidden(adminComponent, packageName, !hidden)

            val message = if (hidden) {
                "'$packageName' enabled in Work Profile."
            } else {
                "'$packageName' hidden in Work Profile."
            }
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            Toast.makeText(
                this,
                "Failed to modify app in Work Profile: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}

class AppListAdapter(
    private val apps: List<ApplicationInfo>,
    private val packageManager: PackageManager,
    private val onCloneClick: (ApplicationInfo) -> Unit
) : RecyclerView.Adapter<AppListAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.ivAppIcon)
        val name: TextView = view.findViewById(R.id.tvAppName)
        val pkg: TextView = view.findViewById(R.id.tvPackageName)
        val btnClone: Button = view.findViewById(R.id.btnClone)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(app.loadIcon(packageManager))
        holder.name.text = app.loadLabel(packageManager).toString()
        holder.pkg.text = app.packageName
        holder.btnClone.setOnClickListener { onCloneClick(app) }
    }

    override fun getItemCount() = apps.size
}
