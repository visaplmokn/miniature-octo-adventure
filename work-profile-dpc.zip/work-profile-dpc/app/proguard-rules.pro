# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in /path/to/android-sdk/tools/proguard/proguard-android.txt

-keep class com.example.workprofiledpc.** { *; }
-keepclassmembers class com.example.workprofiledpc.MyDeviceAdminReceiver {
    public *;
}
